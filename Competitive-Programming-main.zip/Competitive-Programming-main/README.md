# Total Problem Solved
### Last Updated: 13 June, 2024

| Online Judge | Username | Total Problem Solve | Max Rating |
|:------------:|:--------:|:-----------:|:----------:|
| Codeforces   | [Nocturnality](https://codeforces.com/profile/Nocturnality)                  | 2119 | 1649 |
| CodeChef     | [ahad_42](https://www.codechef.com/users/ahad_42)                            | 207  | 1709 |
| Vjudge       | [ahad_cse8](https://vjudge.net/user/ahad_cse8)                               | 188  |
| LeetCode     | [Ahad_41](https://leetcode.com/u/Ahad_41)                                    | 152  | 1695 |
| Beecrowd     | [SecretCoder](https://judge.beecrowd.com/en/profile/646529)                  | 133  |
| LightOJ      | [ahad.cse8.bu](https://lightoj.com/user/ahad.cse8.bu)                        | 171  |
| CSES         | [Ahad -->](https://cses.fi/user/134325)                                      | 112  |
| Toph         | [Ahad_41](https://toph.co/u/Ahad_41)                                         | 195  |
| AtCoder      | [Ahad_41](https://atcoder.jp/users/Ahad_41)                                  | 94   | 702  |
| HackerRank   | [ahad_08_41](https://www.hackerrank.com/profile/ahad_08_41)                  | 50   |
| UVa          | [Ahad_41](https://onlinejudge.org/index.php?option=com_comprofiler&Itemid=3) | 40   |
| HackerEarth  | [ahad.cse8.bu](https://www.hackerearth.com/@ahad.cse8.bu)                    | 20   |  
| SPOJ         | [ahad_41](https://www.spoj.com/myaccount/)                                   | 16   |
| ***Total***  |                                                                              | ***3497*** |
