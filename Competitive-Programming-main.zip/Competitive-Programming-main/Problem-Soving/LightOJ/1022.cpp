void answer(){
    double r; cin >> r;
    double pi = 4 - (2.0 * acos(0.0));
    cout << fixed << setprecision(2) << r*r*pi  << endl;
}
